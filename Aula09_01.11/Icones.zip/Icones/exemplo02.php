<html>
<head></head>
<body>

<table border='1px'>
<tr><td><img src='icones/icone01.png'></td></tr>
<tr><td><img src='icones/icone02.png'></td></tr>
<tr><td><img src='icones/icone03.png'></td></tr>
<tr><td><img src='icones/icone04.png'></td></tr>
<tr><td><img src='icones/icone05.png'></td></tr>
</table>
</body>
</html>



