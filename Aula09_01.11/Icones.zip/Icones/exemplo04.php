<html>
<head>
<?php
$icone = array();
$icone[0] = 'icone01.png';
$icone[1] = 'icone02.png';
$icone[2] = 'icone03.png';
$icone[3] = 'icone04.png';
$icone[4] = 'icone05.png';
?>


</head>
<body>

<table border='1px'>
<?php
	echo "<tr><td><img src='icones/";
	echo $icone[0];
	echo "'></td></tr>";
?>

</table>
</body>
</html>



