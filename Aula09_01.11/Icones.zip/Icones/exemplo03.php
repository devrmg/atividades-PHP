<html>
<head>
<?php
$icone = array();
$icone[0] = 'icone01.png';
$icone[1] = 'icone02.png';
$icone[2] = 'icone03.png';
$icone[3] = 'icone04.png';
$icone[4] = 'icone05.png';
?>


</head>
<body>

<table border='1px'>
<tr><td><img src='icones/<?php echo $icone[0];?>'></td></tr>
<tr><td><img src='icones/<?php echo $icone[1];?>'></td></tr>
<tr><td><img src='icones/<?php echo $icone[2];?>'></td></tr>
<tr><td><img src='icones/<?php echo $icone[3];?>'></td></tr>
<tr><td><img src='icones/<?php echo $icone[4];?>'></td></tr>
</table>
</body>
</html>



