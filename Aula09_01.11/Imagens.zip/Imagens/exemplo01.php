<?php

echo "<img src='jogos/jogo01.png'>";

?>
