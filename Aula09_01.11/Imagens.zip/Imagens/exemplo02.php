<?php

$imagem = "jogo01.png";

echo "<img src='jogos/$imagem'>";

?>
