<?php
    date_default_timezone_set('America/Sao_Paulo');
    $dataLocal = date('d/m/Y');
	echo $dataLocal;
?>






