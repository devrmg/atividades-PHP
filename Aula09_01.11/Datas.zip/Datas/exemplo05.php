<?php
require('bibliotecadata.php');
echo cidadedata();
	
?>


